export default {
  CURRENCY: "rsd",
};

export const categories = ["pizza", "sandwitch", "pancakes", "other"];
export const stages = ["Accepted", "Preparing", "On The Way", "Delivered"];
