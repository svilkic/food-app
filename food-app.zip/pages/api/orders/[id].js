export async function handler(req, res) {
  const { method } = req;
  if (method === "GET") {
  } else if (method === "POST") {
  } else if (method === "PUT") {
  } else if (method === "DELETE") {
  }
}
